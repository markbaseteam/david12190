
Para ver como funciona el sync con internet.
